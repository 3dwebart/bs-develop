# ARIA Roles and Attributes unsupported in axe-core.

## Roles

| aria-role | axe-core support |
| --------- | ---------------- |
| figure    | No               |

## Attributes

| aria-attribute       | axe-core support |
| -------------------- | ---------------- |
| aria-describedat     | No               |
| aria-details         | No               |
| aria-roledescription | No               |