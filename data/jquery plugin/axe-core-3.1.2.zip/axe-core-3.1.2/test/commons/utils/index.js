describe('utils.escapeSelector', function() {
	'use strict';

	it('should be a function', function() {
		assert.isFunction(axe.commons.utils.escapeSelector);
	});
});
describe('utils.matchesSelector', function() {
	'use strict';

	it('should be a function', function() {
		assert.isFunction(axe.commons.utils.matchesSelector);
	});
});
describe('utils.clone', function() {
	'use strict';

	it('should be a function', function() {
		assert.isFunction(axe.commons.utils.clone);
	});
});
