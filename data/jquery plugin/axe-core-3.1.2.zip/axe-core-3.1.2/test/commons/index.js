describe('axe.commons', function() {
	'use strict';

	it('should be an object', function() {
		assert.isObject(axe.commons);
	});
});
