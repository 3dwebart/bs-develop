describe('exists', function() {
	'use strict';

	it('should return true', function() {
		assert.isTrue(checks.exists.evaluate());
	});
});
